<table cellpadding="20">

    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".6"/>
            </barcode><br></td>
    </tr>


</table>