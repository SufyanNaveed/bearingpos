<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Print BarCode</title>
    <style>  @page {
            margin: 0 auto;
            sheet-size: 300px 250mm;
        }
    </style>
</head>
<body>
<table cellpadding="20">

    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>

    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>

    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>

    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>

    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>
    <tr>
        <td>
            <small><?= $name ?><br><br></small>
            <barcode type="<?= $ctype ?>" code="<?= $code ?>" text="1" class="barcode" height=".7"/>
            </barcode><br></td>


    </tr>
</table>
</body>
</html>