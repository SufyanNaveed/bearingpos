<link rel="stylesheet" type="text/css" href="<?=assets_url() ?>app-assets/vendors/css/calendars/fullcalendar.min.css?v=<?= APPVER ?>">
<link href="<?php echo base_url(); ?>assets/c_portcss/bootstrapValidator.min.css?v=<?= APPVER ?>" rel="stylesheet"/>
<link href="<?php echo base_url(); ?>assets/c_portcss/bootstrap-colorpicker.min.css?v=<?= APPVER ?>" rel="stylesheet"/>
<!-- Custom css  -->
<link href="<?php echo base_url(); ?>assets/c_portcss/custom.css?v=<?= APPVER ?>" rel="stylesheet"/>

<script src='<?php echo base_url(); ?>assets/c_portjs/bootstrap-colorpicker.min.js?v=<?= APPVER ?>'></script>


<div class="content">
    <div class="card card-block">
         <div class="card-body">
        <!-- Notification -->
        <div class="alert"></div>


        <div id='adate'></div>
    </div></div>
</div>

<script src="<?=assets_url() ?>app-assets/vendors/js/extensions/moment.min.js?v=<?= APPVER ?>"></script>
<script src="<?=assets_url() ?>app-assets/vendors/js/extensions/fullcalendar.min.js?v=<?= APPVER ?>"></script>
<script src='<?php echo base_url(); ?>assets/c_portjs/main.js?v=<?= APPVER ?>'></script>